#!/bin/bash

usearch -fastq_mergepairs *_R1.fq -fastqout all_samples_merged.fq -relabel @

usearch -fastx_subsample all_samples_merged.fq -sample_size 5000 -fastqout all_sub_for_primer_check.fq
usearch -search_oligodb all_sub_for_primer_check.fq -db primers.fa -strand both -userout primer_hits.txt -userfields query+qlo+qhi+qstrand
usearch -fastx_truncate all_samples_merged.fq -stripleft 19 -stripright 20 -fastqout all_merged_no_primers.fq

usearch -fastq_filter all_merged_no_primers.fq -fastq_maxee 1 -fastaout QCd_merged.fa

usearch -fastx_uniques QCd_merged.fa -sizeout -relabel Uniq -fastaout unique_seqs.fa

usearch -unoise3 unique_seqs.fa -zotus ASVs.fa -tabbedout unoise3.txt

sed -i.tmp 's/Zotu/ASV_/' ASVs.fa

usearch -otutab all_merged_no_primers.fq -zotus ASVs.fa -otutabout ASV_counts.txt -id 0.985

usearch -sintax ASVs.fa -db rdp_16s_v16_sp.fa -tabbedout ASV_tax_raw.txt -strand both -sintax_cutoff 0.5


sed -i.tmp 's/#OTU ID//' ASV_counts.txt
cp ASV_counts.txt R_working_dir/
bash convert_usearch_tax.sh
cp ASV_tax.txt R_working_dir/
