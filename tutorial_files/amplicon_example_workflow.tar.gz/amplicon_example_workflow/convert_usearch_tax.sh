#!/bin/bash

cut -f1 ASV_tax_raw.txt > ASV_IDs
cut -f4 ASV_tax_raw.txt > raw_tax

cut -d : -f2 raw_tax | cut -d , -f1 | sed 's/\"//g' > domain
cut -d : -f3 raw_tax | cut -d , -f1 | sed 's/\"//g' > phylum
cut -d : -f4 raw_tax | cut -d , -f1 | sed 's/\"//g' > class
cut -d : -f5 raw_tax | cut -d , -f1 | sed 's/\"//g' > order
cut -d : -f6 raw_tax | cut -d , -f1 | sed 's/\"//g' > family
cut -d : -f7 raw_tax | cut -d , -f1 | sed 's/\"//g' > genus
cut -d : -f8 raw_tax | cut -d , -f1 | sed 's/\"//g' > species

paste ASV_IDs domain phylum class order family genus species > tax_temp

echo -e "\tDomain\tPhylum\tClass\tOrder\tFamily\tGenus\tSpecies" > header

cat header tax_temp > ASV_tax.txt

rm ASV_IDs raw_tax domain phylum class order family genus species tax_temp header
